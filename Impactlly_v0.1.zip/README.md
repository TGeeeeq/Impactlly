# Good Deeds Network

> Earn verified digital rewards for real-world environmental and community impact.

A mobile-first Progressive Web App that enables volunteers worldwide to complete environmental cleanup tasks, receive AI-verified rewards, and contribute to measurable global change. Built with Next.js, Supabase, and OpenAI Vision for production-grade impact tracking.

[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Node](https://img.shields.io/badge/node-%3E%3D18.0.0-blue.svg)](https://nodejs.org/)
[![Status](https://img.shields.io/badge/status-MVP%20Ready-brightgreen.svg)]()

## 🌍 Features

### User Features
- **Impact Map**: Interactive global map showing all tasks and completed actions
- **Task Discovery**: Find cleanup and community help tasks near you
- **Photo Verification**: Upload before/after proof of completion
- **AI Verification**: Automatic image analysis detects trash removed and validates proof
- **Token Rewards**: Earn Impact Tokens verified by AI
- **Leaderboards**: Global, country, and city rankings
- **Badges**: 10+ achievements to unlock through various activities
- **Challenges**: Join time-limited community impact campaigns
- **User Profiles**: Track personal impact score, level, and badges

### Organization Features
- Create tasks for volunteer cleanup/help
- View real-time task analytics
- Monitor impact generated
- Manage task rewards and incentives

### Sponsor Features
- Launch impact campaigns
- Allocate reward tokens
- Track ROI and participation

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ with pnpm
- Supabase account (with connected integration)
- Vercel Blob storage (with connected integration)
- OpenAI API key

### Installation

```bash
# Clone and install
git clone <repo-url>
cd good-deeds-network
pnpm install

# Environment variables (automatic from integrations)
# Add OPENAI_API_KEY to Vercel Settings → Vars
# OR create .env.local from .env.example

# Start development server
pnpm dev

# Open http://localhost:3000
```

## 📚 Documentation

- **[MVP_SUMMARY.md](MVP_SUMMARY.md)** - Complete feature overview and implementation status
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - System design, database schema, API design
- **[DEVELOPMENT.md](DEVELOPMENT.md)** - Setup guide, workflows, debugging tips
- **[.env.example](.env.example)** - Environment variable reference

## 🏗️ Architecture

### Tech Stack
- **Frontend**: Next.js 16, React 19, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Next.js Route Handlers, Supabase PostgreSQL
- **Database**: PostgreSQL with Row Level Security
- **Storage**: Vercel Blob (private)
- **AI**: OpenAI GPT-4o Vision for image verification
- **Maps**: Leaflet with OpenStreetMap
- **Auth**: Supabase Auth (Email, OAuth)

### Database Schema
```
profiles
├── User accounts with roles and stats
├── Impact score, tokens, level
└── Location, badges, completed tasks

organizations
├── NGOs, municipalities, community centers
├── Tasks they create
└── Impact they generate

sponsors
├── Companies, foundations
├── Campaigns and token allocation
└── ROI tracking

tasks
├── Cleanup/help actions
├── Location (lat/lng)
├── Difficulty, category, reward
└── Participants

task_submissions
├── User task completions
├── Before/after photos
├── AI analysis results
└── Tokens awarded

badges
├── Achievement definitions
├── Unlock criteria
└── User progress

challenges
├── Time-limited campaigns
├── Target kg or task count
└── Bonus tokens

token_transactions
├── Audit trail
├── All token movements
└── Transaction types
```

### Data Flow
```
User starts task
    ↓
Captures location (GPS)
    ↓
Takes before photo
    ↓
Completes real-world action
    ↓
Takes after photo
    ↓
Submits to platform
    ↓
AI verification (OpenAI Vision)
    ├─ Detects trash
    ├─ Validates scene match
    ├─ Checks for manipulation
    └─ Estimates waste volume
    ↓
If approved:
  ├─ Award tokens
  ├─ Update impact score
  ├─ Check badge unlocks
  └─ Update leaderboard
    ↓
User sees reward confirmation
```

## 🔐 Security

### Authentication
- Supabase Auth with bcrypt password hashing
- JWT tokens in httpOnly cookies
- Support for Google & Apple OAuth
- Session management via proxy

### Data Protection
- Row Level Security (RLS) on all tables
- Private blob storage for uploads
- CORS validation, file type checking
- Image deduplication via hashing

### Fraud Prevention
- GPS location validation
- EXIF metadata checking
- Timestamp validation
- Rate limiting (5 submissions/day)
- Anomaly detection

## 📊 Performance

### Optimization
- Image optimization with next/image
- Code splitting by route
- Service Worker for offline support
- SWR client-side caching with 60s refresh
- Lazy-loaded map and heavy components

### Target Metrics
- Page load: < 2s on 4G
- Task submission: < 20s total time
- AI verification: 5-10s response
- Map render: < 1s for 100 tasks

### Scaling Path
- MVP: 10k DAU, 100k MAU
- Phase 1: Add Redis caching, geospatial indexing
- Phase 2: Regional databases, dedicated AI workers
- Phase 3: Global edge distribution, blockchain tokens

## 🧪 Testing

### Manual Testing
```bash
# Sign up with test account
Email: test@example.com
Password: TestPassword123!

# Complete flow
1. Browse tasks on map
2. Select nearest task
3. Click "Start Task"
4. Upload before photo
5. Complete task form
6. Upload after photo
7. Submit
8. Watch verification API call
9. Refresh profile to see tokens
10. Check leaderboard ranking
11. View new badges unlocked
```

### Device Testing
- iPhone 12/14/16 (Safari)
- Android Pixel 6/7/8 (Chrome)
- iPad Pro (landscape)
- Desktop (1920x1080, 1440x900)

## 🚢 Deployment

### One-Click Deployment
```bash
# Push to GitHub
git push origin main

# Auto-deploys to Vercel with:
# - Production environment
# - All integrations configured
# - Database migrations auto-run
# - Environment variables from Vercel Settings
```

### Pre-Deployment Checklist
- [ ] All env vars set in Vercel Settings
- [ ] Database migrations run (check Supabase)
- [ ] Seed data loaded (verify global_stats exists)
- [ ] Blob storage working (test file upload)
- [ ] OpenAI API key valid (test verification)
- [ ] OAuth providers configured
- [ ] PWA manifest.json correct
- [ ] Error pages created

## 📈 API Endpoints

### Authentication
```
POST /auth/sign-up          Register user
POST /auth/login            Email login
POST /auth/sign-out         Logout
```

### Tasks
```
GET /api/tasks              List with filters (category, difficulty, radius)
POST /api/tasks             Create task (org/sponsor)
GET /api/tasks/[id]         Task details
```

### Submissions
```
POST /api/submissions       Submit task completion
GET /api/submissions        User's history
GET /api/submissions/[id]  Details with AI analysis
```

### Verification
```
POST /api/verify            AI image verification
```

### Gamification
```
GET /api/leaderboard       Global/country/city rankings
GET /api/badges            Available badges + progress
POST /api/badges           Award badge
```

### Storage
```
POST /api/upload           Upload images to Blob
```

## 🛠️ Development

### Common Tasks

**Add a new badge type:**
1. Insert in `004_seed_data.sql`
2. Update badge logic in `/app/api/verify/route.ts`
3. Add UI card in `/app/(app)/badges/page.tsx`

**Create a new task category:**
1. Update `lib/types.ts` → TaskCategory
2. Add check constraint in database
3. Update icon in `lib/utils/calculations.ts`
4. Update filter UI in `components/map-filters.tsx`

**Extend AI verification:**
1. Edit `/app/api/verify/route.ts`
2. Modify OpenAI prompt
3. Update fraud detection thresholds
4. Add fields to `ai_analysis` JSONB

### Debugging
```typescript
// Enable debug logging
console.log('[v0] Debug message:', data)

// Query database in SQL editor
SELECT * FROM public.task_submissions WHERE status = 'pending';

// Check AI responses in network tab
// Verify image URLs are accessible
// Validate Supabase RLS policies
```

## 📱 PWA Features

- **Installable**: Add to home screen on iOS/Android
- **Offline**: Service Worker enables offline fallback
- **Responsive**: Mobile-first design, works on all devices
- **App-like**: Standalone display mode, no address bar
- **Fast**: Cached assets for instant loading

## 🤝 Contributing

This MVP is designed to be extended. The codebase follows these principles:

- **Modular**: Components, APIs, and database layers are independent
- **Documented**: Code comments explain the "why" behind decisions
- **Scalable**: Architecture supports 10M+ DAU with optimizations
- **Secure**: RLS, input validation, fraud prevention built-in

## 📄 License

MIT License - see LICENSE file for details

## 🙏 Acknowledgments

Built with:
- [Next.js](https://nextjs.org) - React framework
- [Supabase](https://supabase.com) - PostgreSQL + Auth
- [Vercel](https://vercel.com) - Hosting + Blob storage
- [OpenAI](https://openai.com) - Vision API
- [Tailwind CSS](https://tailwindcss.com) - Styling
- [shadcn/ui](https://ui.shadcn.com) - Components
- [Leaflet](https://leafletjs.com) - Maps

## 📞 Support

### Documentation
- See [DEVELOPMENT.md](DEVELOPMENT.md) for setup and workflows
- See [ARCHITECTURE.md](ARCHITECTURE.md) for system design
- See [MVP_SUMMARY.md](MVP_SUMMARY.md) for feature checklist

### Troubleshooting
1. Check [DEVELOPMENT.md](DEVELOPMENT.md) Common Issues section
2. Review Vercel deployment logs
3. Check Supabase database logs
4. Verify environment variables are set
5. Test in local dev environment first

### Issues
Submit issues on GitHub with:
- Device/browser info
- Steps to reproduce
- Error message/screenshot
- Expected vs actual behavior

---

**Built with ❤️ for global environmental impact**

[Visit Website](#) | [Discord Community](#) | [Twitter](#)

Last Updated: April 2026  
Version: 1.0.0-MVP  
Status: ✅ Production Ready
